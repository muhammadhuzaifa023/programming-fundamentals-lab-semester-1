# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
f=open('sample.txt','r')# It helps to count the total characters.
strs=f.read()
lst=strs.split()
print('no of words are',len(strs))


print('no of lines are',lst.count())
f.close()
strs=f.read()
print(strs)

f.close()

f=open('sample.txt','r')
strs=f.read()
lst=strs.split()
print('no of words are',chr(strs))
#Q!
def stats(filename):
    f=open('sample.txt','r')
    strs=f.read()
    print('line count:',len(strs.split()))
    print('no of words are:',len(strs.split(strs)))
    print('no of characters are:',len(strs.split()))
    
    
f=open('test file.txt','w')
f.write('This is python')
f.close()

f=open('test file.txt','r')
g=f.read()
print(g)
f.close()

f=open('test file.txt','a') #IF i want to append any text
f.write('This is what we do')
f.close()

f=open('sample.txt','r')
strs=f.readline()
lst=strs.split()
print(len(strs))

f=open('sample.txt','a')
g=f.write('\nI have a car')
f.close()
#Q2:
def distribution(filename):
    f=open(filename,'r')
    strs=f.read()
    lst=strs.split()
    num=[6,2,3,2,2,4,1,2]
    for i in range(len(num)):
        print(num[i],'students got',lst[i])
distribution('Grade.txt')
        
def duplicate(filename):
    f=open(filename,'r')
    strs=f.read()
    lst=strs.split()
    
    if (len(lst)!= len(set(lst))):
        return True
    else:
        return False
duplicate('Duplicate.txt')
        
f.close()  








